from django.apps import AppConfig


class CronjobsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'cronjobs'
